source pypole/bin/activate
python pole.py
