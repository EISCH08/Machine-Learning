###############################
##
##  Environment
##
################################
#
# Num	Observation	       Min	    Max
# 0	Cart Position	       -2.4	    2.4
# 1	Cart Velocity	       -Inf	    Inf
# 2	Pole Angle	       ~ -41.8 dgr  ~ 41.8 dgr
# 3	Pole Velocity At Tip   -Inf	    Inf
#
#
# Num   Action
# 0     Move left
# 1     Move right
#



###############################
##
##  External Variables
##
###############################


##
## Buckets
##
#
# These are used to discretize the input space.
# Each list gives the borders between the ranges.
#
# For example given
#   cartPositionBuckets = [-1, 0, 1]
# will yield four buckets:
#   (-Inf, -1] & (-1, 0] & (0, 1] & (1, +Inf)
#
# If a list is left empty, the resulting input
# will effectively be ignored.

cartPositionBuckets = [0]
cartVelocityBuckets = [0]
poleAngleBuckets = [0]
poleVelocityBuckets = [0]

##
## Q-Learning parameters
##


# Standard parameters
learning_rate = 0.95
discount_factor = 1.00
exploration_rate = 0.95
epochs = 200

# Number of visualized (greedy) epochs at end of experiment
# Use these for evaluating your solution.
epochsVisualized = 10


###############################
##
##  Internal Variables
##
###############################

import numpy
import random
import gym

greedy = False

qt = numpy.zeros((
    len(cartPositionBuckets) + 1,
    len(cartVelocityBuckets) + 1,
    len(poleAngleBuckets) + 1,
    len(poleVelocityBuckets) + 1,
    2))

at = numpy.zeros((
    len(cartPositionBuckets) + 1,
    len(cartVelocityBuckets) + 1,
    len(poleAngleBuckets) + 1,
    len(poleVelocityBuckets) + 1,
    2))


def qtable(cartPosition, cartVelocity, poleAngle, poleVelocity, action):
    return qt[cartPosition][cartVelocity][poleAngle][poleVelocity][action]

def qtableAssign(cartPosition, cartVelocity, poleAngle, poleVelocity, action, val):
    qt[cartPosition][cartVelocity][poleAngle][poleVelocity][action] = val

def atableAssign(cartPosition, cartVelocity, poleAngle, poleVelocity, action):
    at[cartPosition][cartVelocity][poleAngle][poleVelocity][action] += 1

def getBucket(value, buckets):
    i=0
    while (i < len(buckets) and value > buckets[i]):
        i += 1
    return i

def calcAction(cartPosition, cartVelocity, poleAngle, poleVelocity):
    action = 0
    if (not greedy and random.uniform(0, 1) <= exploration_rate):
        action = random.choice([0, 1])
    else:

        left = qtable(cartPosition,cartVelocity,poleAngle,poleVelocity,0)
        right = qtable(cartPosition,cartVelocity,poleAngle,poleVelocity,1)
        if (left > right):
            action = 0
        else:
            action = 1
    return action

env = gym.make('CartPole-v0')

def bucketize(observations):
    # Bucket state values
    cartPositionVal = getBucket(observation[0], cartPositionBuckets)
    # print(f"cartPosition: {observation[0]} -> {cartPositionVal}")

    cartVelocityVal = getBucket(observation[1], cartVelocityBuckets)
    # print(f"cartVelocity: {observation[1]} -> {cartVelocityVal}")

    poleAngleVal = getBucket(observation[2], poleAngleBuckets)
    # print(f"poleAngleVal: {observation[2]} -> {poleAngleVal}")

    poleVelocityVal = getBucket(observation[3], poleVelocityBuckets)
    # print(f"poleVelocityVal: {observation[3]} -> {poleVelocityVal}")

    return (cartPositionVal, cartVelocityVal, poleAngleVal, poleVelocityVal)



poleAngles = []
poleVelocities = []


for i_episode in range(epochs+epochsVisualized):
    observation = env.reset()
    if (i_episode==epochs):
        print("Starting Greedy Runs")
        greedy = True
    for t in range(2000):
        if (greedy):
            env.render()

        (cartPosition, cartVelocity, poleAngle, poleVelocity) = bucketize(observation)

        action = calcAction(cartPosition, cartVelocity, poleAngle, poleVelocity)

        newObservation, reward, done, info = env.step(action)
        poleAngles.append(newObservation[2])
        poleVelocities.append(newObservation[3])        
        (newCartPosition, newCartVelocity, newPoleAngle, newPoleVelocity) = bucketize(newObservation)        

        if done:
            reward = -10
        #     print("Negative reward propagated...")
            
        oldQ = qtable(cartPosition,cartVelocity,poleAngle,poleVelocity,action)
        maxQ = max(qtable(newCartPosition,newCartVelocity,newPoleAngle,newPoleVelocity,0),
                   qtable(newCartPosition,newCartVelocity,newPoleAngle,newPoleVelocity,1))
        newQ = (1.0-learning_rate)*oldQ + learning_rate*(reward + discount_factor*maxQ)
        qtableAssign(cartPosition,cartVelocity,poleAngle,poleVelocity,action, newQ)
        atableAssign(cartPosition,cartVelocity,poleAngle,poleVelocity,action)        

        observation = newObservation

        
        
        if done:
            print("Epoch finished after {} timesteps".format(t+1))
            break


# print("<<QT>>")        
# print(qt)
# print("<<AT>>")
# print(at)
# print("poleAnglesMin")
# print(min(poleAngles))
# print("poleAnglesMax")
# print(max(poleAngles))
# print("poleVelocityMin")
# print(min(poleVelocities))
# print("poleVelocityMax")
# print(max(poleVelocities))
